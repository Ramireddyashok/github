# Synopsis

A very simple example demonstrating how the load method allows you to
read in Groovy files from disk or from the web and then call the code in them.
