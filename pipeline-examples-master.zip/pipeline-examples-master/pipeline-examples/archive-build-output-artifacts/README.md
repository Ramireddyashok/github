# Synopsis

This is a simple demonstration of how to archive the build output artifacts in workspace for later use.

