# Pipeline examples

This directory contains various Pipeline examples, showing how to use specific plugins, how the Pipeline DSL works, and more.
